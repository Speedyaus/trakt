﻿angular.module('webtools').service('aboutusModel', function () {
    this.translators = {};
});