﻿angular.module('webtools').controller('headController', ['$scope', 'webtoolsModel', function ($scope, webtoolsModel) {
    $scope.webtoolsModel = webtoolsModel;
}]);