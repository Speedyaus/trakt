﻿angular.module('webtools').controller('clController', ['$scope', 'clModel', 'clService', function ($scope, clModel, clService) {
    $scope.clModel = clModel;
}]);