﻿angular.module('webtools').service('clModel', function () {

});