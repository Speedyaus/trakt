﻿angular.module('webtools').service('clService', ['$http', 'clModel', function ($http, clModel) {

}]);