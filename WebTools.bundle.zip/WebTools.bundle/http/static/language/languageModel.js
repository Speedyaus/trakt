﻿angular.module('webtools').service('languageModel', function () {
    this.languages = [];
    this.codeLanguages = [];
});