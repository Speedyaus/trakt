﻿angular.module('webtools').service('menuModel', function () {
    this.visible = true;
});