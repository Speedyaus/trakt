﻿angular.module('webtools').service('themeModel', function () {
    this.activeTheme = "WhiteBlue.css";
    this.themes = [];
});