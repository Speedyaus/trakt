﻿angular.module('webtools').service('playlistModel', function () {
    this.playlists = [];
    this.selectedFile = null;
});