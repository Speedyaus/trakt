﻿angular.module('webtools').service('infoModel', function () {
    this.informations = [];
});