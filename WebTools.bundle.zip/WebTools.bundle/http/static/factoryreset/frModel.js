﻿angular.module('webtools').service('frModel', function () {

});