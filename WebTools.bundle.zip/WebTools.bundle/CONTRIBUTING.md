Please see https://github.com/ukdtom/WebTools.bundle/wiki/Developer
